<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components.css')); ?>">
    <title>Regalos E y K</title>
</head>

<body>
    <div class="loader"></div>
    <div class="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
<script src="<?php echo e(asset('js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

</html>
<?php /**PATH /home/eliacer/Repositorios/wedding-page/resources/views/layout/panel-user.blade.php ENDPATH**/ ?>