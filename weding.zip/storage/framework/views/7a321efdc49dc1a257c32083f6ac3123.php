<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-12 col-lg-12-col-sm-12">
        <div class="card">
            <div class="card-header">
                <h4 class="text-center"> Elige tu regalo para nosotros </h4>
            </div>

            <div class="card-body">
                <div class="row">
                    <?php $__currentLoopData = $regalos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regalo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xl-3">
                            <div class="card">

                                <img src="<?php echo e(asset($regalo->rega_ruta_imagen)); ?>"
                                    style="width: 100%;height: 100%;">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($regalo->rega_nombre); ?></h5>
                                    <p class="card-text"><?php echo e($regalo->rega_descripcion); ?> <br> <a
                                            href="<?php echo e($regalo->rega_link); ?>">Enlace de
                                            referencia</a> <br>
                                        <?php if($regalo->rega_estado == 1): ?>
                                            <div class="badge badge-success badge-shadow">
                                                <i class="fas fa-check"></i> Disponible
                                            </div>
                                        <?php else: ?>
                                            <div class="badge badge-danger badge-shadow">
                                                <i class="fas fa-times"></i> Reservado
                                            </div>
                                        <?php endif; ?>
                                    </p>
                                    <?php if($regalo->rega_estado == 1): ?>
                                        <a href="" class="btn btn-primary">Reservar regalo</a>
                                    <?php else: ?>
                                        <button class="btn btn-danger">Reservado</button>
                                    <?php endif; ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.panel-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/eliacer/Repositorios/wedding-page/resources/views/gifts/gift.blade.php ENDPATH**/ ?>